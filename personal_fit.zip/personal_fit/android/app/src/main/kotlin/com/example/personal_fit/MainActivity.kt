package com.example.personal_fit

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
