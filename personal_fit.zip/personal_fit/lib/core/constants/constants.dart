class AppConstants {
  static const String apiBaseUrl = 'https://your-mockapi-url.com';
}
