// lib/modules/personals/data/repositories/personal_repository.dart

import '../../domain/entities/personal.dart';

abstract class PersonalRepository {
  Future<List<Personal>> getAll();
}
